# Install

`pip install gixpy`

# How to use

Here's an example of N files from a directory and transforming them all at once. ***WARNING*** Currently there is a bug when you feed in a list or tuple of arrays. Every transformation gets saved over the first image of the return arrays. Instead just run the function on each array separately. The function is fast, so this shouldn't be a big problem for now (I'm moving on to more important things at the moment, and may come back and fix this bug).

